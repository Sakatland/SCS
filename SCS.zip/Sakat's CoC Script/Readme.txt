 ┌────────────────────────────────────────────────────────────────────────────┐
 │                     Valais (#9PJYL) proudly presents:                      │
 │                             Sakat's CoC Script                             │
 ├─────────────────────────────────────┬──────────────────────────────────────┤
 │ Date: 2019-02-25                    │ Version: 0.6                         │
 └─────────────────────────────────────┴──────────────────────────────────────┘

 
 Notes 
 ~~~~~
 
	This script is based on ClashOfClansAPI (1.0.4) by Tony Benoy. For more info, please check his github on:
                        github.com/tonybenoy/cocapi/
	
	For the script to work properly you need:
 
	* Your own API token (added in Token.txt)
	* Run the script during CWL (for option #4)
	* Prepare Warlogs.txt (for option #5)
	* An internet connection
 
 
 How to use it
 ~~~~~~~~~~~~~
 
 1. Create your own API token:
 
	- Open https://developer.clashofclans.com/
	- Register
	- Click on your account
	- Create New Key
	- Enter Key Name (doesn't matter), Description (doesn't matter) and your IP
	- Copy-paste your token into Token.txt (must be in the same folder and without space char before or after)

	Remark:
	If you don't know your IP go to www.whatismyip.com
	Your API token is linked to your IP, so when your IP changes you need to create a new one

	
 2. Prepare Warlogs.txt:
 
	- If you want to use the script when no CWL is taking place,
	  you need to have a file called Warlogs.txt (in the same folder)

	  
 3. Execute .exe and enter the information asked!
 
 ~~~~~~~~~~~~~~~~~~~~~~    
 
			       IF YOU LIKE IT CHECK ANOTHER PROJECT WE DID:
			            =======>  www.cgleech.tk <=======